from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution, FindExecutable
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # -------------------------------------------------
    # 1️⃣ Define file paths and parameters
    # -------------------------------------------------
    my_robot_description = FindPackageShare("my_robot_description")
    my_robot_bringup = FindPackageShare("my_robot_bringup")
    gazebo_ros = FindPackageShare("gazebo_ros")

    urdf_path = PathJoinSubstitution([my_robot_description, "urdf", "my_robot.urdf.xacro"])
    world_path = PathJoinSubstitution([my_robot_bringup, "worlds", "test_world.world"])
    rviz_config_path = PathJoinSubstitution([my_robot_bringup, "rviz", "urdf_config.rviz"])

    # -------------------------------------------------
    # 2️⃣ Robot State Publisher
    # -------------------------------------------------
    # Converts the URDF/XACRO into the robot_description parameter
    robot_state_publisher_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{
            "robot_description": Command(["xacro ", urdf_path])
        }],
        output="screen"
    )

    # -------------------------------------------------
    # 3️⃣ Launch Gazebo
    # -------------------------------------------------
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([gazebo_ros, "/launch/gazebo.launch.py"]),
        launch_arguments={"world": world_path}.items()
    )

    # -------------------------------------------------
    # 4️⃣ Spawn the Robot into Gazebo
    # -------------------------------------------------
    spawn_robot = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        arguments=["-topic", "robot_description", "-entity", "my_robot"],
        output="screen"
    )

    # -------------------------------------------------
    # 5️⃣ Launch RViz2
    # -------------------------------------------------
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=["-d", rviz_config_path]
    )

    # -------------------------------------------------
    # 6️⃣ Combine everything into a LaunchDescription
    # -------------------------------------------------
    return LaunchDescription([
        robot_state_publisher_node,
        gazebo_launch,
        spawn_robot,
        rviz_node
    ])

